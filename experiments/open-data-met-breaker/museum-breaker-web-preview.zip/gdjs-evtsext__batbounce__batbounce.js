
gdjs.evtsExt__BatBounce__BatBounce = gdjs.evtsExt__BatBounce__BatBounce || {};

/**
 * Behavior generated from Bat bounce
 */
gdjs.evtsExt__BatBounce__BatBounce.BatBounce = class BatBounce extends gdjs.RuntimeBehavior {
  constructor(instanceContainer, behaviorData, owner) {
    super(instanceContainer, behaviorData, owner);
    this._runtimeScene = instanceContainer;

    this._onceTriggers = new gdjs.OnceTriggers();
    this._behaviorData = {};
    this._sharedData = gdjs.evtsExt__BatBounce__BatBounce.BatBounce.getSharedData(
      instanceContainer,
      behaviorData.name
    );
    
    this._behaviorData.Property = behaviorData.Property !== undefined ? behaviorData.Property : Number("") || 0;
    this._behaviorData.OldX = Number("0") || 0;
    this._behaviorData.OldY = Number("") || 0;
    this._behaviorData.OldForceAngle = Number("") || 0;
    this._behaviorData.OldForceLength = Number("") || 0;
    this._behaviorData.NormalAngle = Number("") || 0;
  }

  // Hot-reload:
  applyBehaviorOverriding(behaviorOverriding) {
    
    if (behaviorOverriding.Property !== undefined)
      this._behaviorData.Property = behaviorOverriding.Property;
    if (behaviorOverriding.OldX !== undefined)
      this._behaviorData.OldX = behaviorOverriding.OldX;
    if (behaviorOverriding.OldY !== undefined)
      this._behaviorData.OldY = behaviorOverriding.OldY;
    if (behaviorOverriding.OldForceAngle !== undefined)
      this._behaviorData.OldForceAngle = behaviorOverriding.OldForceAngle;
    if (behaviorOverriding.OldForceLength !== undefined)
      this._behaviorData.OldForceLength = behaviorOverriding.OldForceLength;
    if (behaviorOverriding.NormalAngle !== undefined)
      this._behaviorData.NormalAngle = behaviorOverriding.NormalAngle;

    return true;
  }

  // Network sync:
  getNetworkSyncData(syncOptions) {
    return {
      ...super.getNetworkSyncData(syncOptions),
      props: {
        
    Property: this._behaviorData.Property,
    OldX: this._behaviorData.OldX,
    OldY: this._behaviorData.OldY,
    OldForceAngle: this._behaviorData.OldForceAngle,
    OldForceLength: this._behaviorData.OldForceLength,
    NormalAngle: this._behaviorData.NormalAngle,
      }
    };
  }
  updateFromNetworkSyncData(networkSyncData, options) {
    super.updateFromNetworkSyncData(networkSyncData, options);
    
    if (networkSyncData.props.Property !== undefined)
      this._behaviorData.Property = networkSyncData.props.Property;
    if (networkSyncData.props.OldX !== undefined)
      this._behaviorData.OldX = networkSyncData.props.OldX;
    if (networkSyncData.props.OldY !== undefined)
      this._behaviorData.OldY = networkSyncData.props.OldY;
    if (networkSyncData.props.OldForceAngle !== undefined)
      this._behaviorData.OldForceAngle = networkSyncData.props.OldForceAngle;
    if (networkSyncData.props.OldForceLength !== undefined)
      this._behaviorData.OldForceLength = networkSyncData.props.OldForceLength;
    if (networkSyncData.props.NormalAngle !== undefined)
      this._behaviorData.NormalAngle = networkSyncData.props.NormalAngle;
  }

  // Properties:
  
  _getProperty() {
    return this._behaviorData.Property !== undefined ? this._behaviorData.Property : Number("") || 0;
  }
  _setProperty(newValue) {
    this._behaviorData.Property = newValue;
  }
  _getOldX() {
    return this._behaviorData.OldX !== undefined ? this._behaviorData.OldX : Number("0") || 0;
  }
  _setOldX(newValue) {
    this._behaviorData.OldX = newValue;
  }
  _getOldY() {
    return this._behaviorData.OldY !== undefined ? this._behaviorData.OldY : Number("") || 0;
  }
  _setOldY(newValue) {
    this._behaviorData.OldY = newValue;
  }
  _getOldForceAngle() {
    return this._behaviorData.OldForceAngle !== undefined ? this._behaviorData.OldForceAngle : Number("") || 0;
  }
  _setOldForceAngle(newValue) {
    this._behaviorData.OldForceAngle = newValue;
  }
  _getOldForceLength() {
    return this._behaviorData.OldForceLength !== undefined ? this._behaviorData.OldForceLength : Number("") || 0;
  }
  _setOldForceLength(newValue) {
    this._behaviorData.OldForceLength = newValue;
  }
  _getNormalAngle() {
    return this._behaviorData.NormalAngle !== undefined ? this._behaviorData.NormalAngle : Number("") || 0;
  }
  _setNormalAngle(newValue) {
    this._behaviorData.NormalAngle = newValue;
  }
}

/**
 * Shared data generated from Bat bounce
 */
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.SharedData = class BatBounceSharedData {
  constructor(sharedData) {
    
  }
  
  // Shared properties:
  
}

gdjs.evtsExt__BatBounce__BatBounce.BatBounce.getSharedData = function(instanceContainer, behaviorName) {
  if (!instanceContainer._BatBounce_BatBounceSharedData) {
    const initialData = instanceContainer.getInitialSharedDataForBehavior(
      behaviorName
    );
    instanceContainer._BatBounce_BatBounceSharedData = new gdjs.evtsExt__BatBounce__BatBounce.BatBounce.SharedData(
      initialData
    );
  }
  return instanceContainer._BatBounce_BatBounceSharedData;
}

// Methods:
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext = {};
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.idToCallbackMap = new Map();
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1= [];
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects2= [];
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1= [];
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects2= [];


gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.eventsList0 = function(runtimeScene, eventsFunctionContext) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1);
{}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(eventsFunctionContext.getObjects("Object"), gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1);
gdjs.copyArray(eventsFunctionContext.getObjects("Obstacle"), gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1);
{for(var i = 0, len = gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1[i].clearForces();
}
}
{for(var i = 0, len = gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1.length ;i < len;++i) {
    gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1[i].addPolarForce(-90 + (((gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1[i].getX()) - (( gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1.length === 0 ) ? 0 :gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1[0].getX())) / ((( gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1.length === 0 ) ? 0 :gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1[0].getWidth()) + (gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1[i].getWidth()))) * 140, (gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1[i].getBehavior(eventsFunctionContext.getBehaviorName("Behavior"))._getOldForceLength()), 1);
}
}
}

}


};

gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOff = function(Obstacle, parentEventsFunctionContext) {

var that = this;
var runtimeScene = this._runtimeScene;
let scopeInstanceContainer = null;
var thisObjectList = [this.owner];
var Object = Hashtable.newFrom({Object: thisObjectList});
var Behavior = this.name;
var eventsFunctionContext = {
  _objectsMap: {
"Object": Object
, "Obstacle": Obstacle
},
  _objectArraysMap: {
"Object": thisObjectList
, "Obstacle": gdjs.objectsListsToArray(Obstacle)
},
  _behaviorNamesMap: {
"Behavior": Behavior
},
  globalVariablesForExtension: runtimeScene.getGame().getVariablesForExtension("BatBounce"),
  sceneVariablesForExtension: runtimeScene.getScene().getVariablesForExtension("BatBounce"),
  localVariables: [],
  getObjects: function(objectName) {
    return eventsFunctionContext._objectArraysMap[objectName] || [];
  },
  getObjectsLists: function(objectName) {
    return eventsFunctionContext._objectsMap[objectName] || null;
  },
  getBehaviorName: function(behaviorName) {
    return eventsFunctionContext._behaviorNamesMap[behaviorName] || behaviorName;
  },
  createObject: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    if (objectsList) {
      const object = parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
        parentEventsFunctionContext.createObject(objectsList.firstKey()) :
        runtimeScene.createObject(objectsList.firstKey());
      if (object) {
        objectsList.get(objectsList.firstKey()).push(object);
        if (!(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName))) {
          eventsFunctionContext._objectArraysMap[objectName].push(object);
        }
      }
      return object;
    }
    return null;
  },
  getInstancesCountOnScene: function(objectName) {
    const objectsList = eventsFunctionContext._objectsMap[objectName];
    let count = 0;
    if (objectsList) {
      for(const objectName in objectsList.items)
        count += parentEventsFunctionContext && !(scopeInstanceContainer && scopeInstanceContainer.isObjectRegistered(objectName)) ?
parentEventsFunctionContext.getInstancesCountOnScene(objectName) :
        runtimeScene.getInstancesCountOnScene(objectName);
    }
    return count;
  },
  getLayer: function(layerName) {
    return runtimeScene.getLayer(layerName);
  },
  getArgument: function(argName) {
    return "";
  },
  getOnceTriggers: function() { return that._onceTriggers; }
};

gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects2.length = 0;

gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.eventsList0(runtimeScene, eventsFunctionContext);
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects1.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObjectObjects2.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects1.length = 0;
gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.BounceOffContext.GDObstacleObjects2.length = 0;


return;
}

gdjs.evtsExt__BatBounce__BatBounce.BatBounce.prototype.doStepPreEvents = function() {
  this._onceTriggers.startNewFrame();
};


gdjs.registerBehavior("BatBounce::BatBounce", gdjs.evtsExt__BatBounce__BatBounce.BatBounce);
