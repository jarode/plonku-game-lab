gdjs.GameCode = {};
gdjs.GameCode.localVariables = [];
gdjs.GameCode.idToCallbackMap = new Map();
gdjs.GameCode.GDBallObjects2_1final = [];

gdjs.GameCode.GDBallObjects1= [];
gdjs.GameCode.GDBallObjects2= [];
gdjs.GameCode.GDBallObjects3= [];
gdjs.GameCode.GDBallObjects4= [];
gdjs.GameCode.GDBallObjects5= [];
gdjs.GameCode.GDPaddleObjects1= [];
gdjs.GameCode.GDPaddleObjects2= [];
gdjs.GameCode.GDPaddleObjects3= [];
gdjs.GameCode.GDPaddleObjects4= [];
gdjs.GameCode.GDPaddleObjects5= [];
gdjs.GameCode.GDBlock_95951Objects1= [];
gdjs.GameCode.GDBlock_95951Objects2= [];
gdjs.GameCode.GDBlock_95951Objects3= [];
gdjs.GameCode.GDBlock_95951Objects4= [];
gdjs.GameCode.GDBlock_95951Objects5= [];
gdjs.GameCode.GDBlock_95952Objects1= [];
gdjs.GameCode.GDBlock_95952Objects2= [];
gdjs.GameCode.GDBlock_95952Objects3= [];
gdjs.GameCode.GDBlock_95952Objects4= [];
gdjs.GameCode.GDBlock_95952Objects5= [];
gdjs.GameCode.GDBlock_95953Objects1= [];
gdjs.GameCode.GDBlock_95953Objects2= [];
gdjs.GameCode.GDBlock_95953Objects3= [];
gdjs.GameCode.GDBlock_95953Objects4= [];
gdjs.GameCode.GDBlock_95953Objects5= [];
gdjs.GameCode.GDPowerUpObjects1= [];
gdjs.GameCode.GDPowerUpObjects2= [];
gdjs.GameCode.GDPowerUpObjects3= [];
gdjs.GameCode.GDPowerUpObjects4= [];
gdjs.GameCode.GDPowerUpObjects5= [];
gdjs.GameCode.GDBarrierObjects1= [];
gdjs.GameCode.GDBarrierObjects2= [];
gdjs.GameCode.GDBarrierObjects3= [];
gdjs.GameCode.GDBarrierObjects4= [];
gdjs.GameCode.GDBarrierObjects5= [];
gdjs.GameCode.GDScoreLabelObjects1= [];
gdjs.GameCode.GDScoreLabelObjects2= [];
gdjs.GameCode.GDScoreLabelObjects3= [];
gdjs.GameCode.GDScoreLabelObjects4= [];
gdjs.GameCode.GDScoreLabelObjects5= [];
gdjs.GameCode.GDStartCard_9595titleObjects1= [];
gdjs.GameCode.GDStartCard_9595titleObjects2= [];
gdjs.GameCode.GDStartCard_9595titleObjects3= [];
gdjs.GameCode.GDStartCard_9595titleObjects4= [];
gdjs.GameCode.GDStartCard_9595titleObjects5= [];
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects1= [];
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2= [];
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects3= [];
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects4= [];
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects5= [];
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1= [];
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2= [];
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects3= [];
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects4= [];
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects5= [];
gdjs.GameCode.GDHome_9595ButtonObjects1= [];
gdjs.GameCode.GDHome_9595ButtonObjects2= [];
gdjs.GameCode.GDHome_9595ButtonObjects3= [];
gdjs.GameCode.GDHome_9595ButtonObjects4= [];
gdjs.GameCode.GDHome_9595ButtonObjects5= [];
gdjs.GameCode.GDReplay_9595ButtonObjects1= [];
gdjs.GameCode.GDReplay_9595ButtonObjects2= [];
gdjs.GameCode.GDReplay_9595ButtonObjects3= [];
gdjs.GameCode.GDReplay_9595ButtonObjects4= [];
gdjs.GameCode.GDReplay_9595ButtonObjects5= [];
gdjs.GameCode.GDLife_9595CounterObjects1= [];
gdjs.GameCode.GDLife_9595CounterObjects2= [];
gdjs.GameCode.GDLife_9595CounterObjects3= [];
gdjs.GameCode.GDLife_9595CounterObjects4= [];
gdjs.GameCode.GDLife_9595CounterObjects5= [];
gdjs.GameCode.GDOnFireParticleObjects1= [];
gdjs.GameCode.GDOnFireParticleObjects2= [];
gdjs.GameCode.GDOnFireParticleObjects3= [];
gdjs.GameCode.GDOnFireParticleObjects4= [];
gdjs.GameCode.GDOnFireParticleObjects5= [];
gdjs.GameCode.GDPaddleLineObjects1= [];
gdjs.GameCode.GDPaddleLineObjects2= [];
gdjs.GameCode.GDPaddleLineObjects3= [];
gdjs.GameCode.GDPaddleLineObjects4= [];
gdjs.GameCode.GDPaddleLineObjects5= [];
gdjs.GameCode.GDBackdropObjects1= [];
gdjs.GameCode.GDBackdropObjects2= [];
gdjs.GameCode.GDBackdropObjects3= [];
gdjs.GameCode.GDBackdropObjects4= [];
gdjs.GameCode.GDBackdropObjects5= [];
gdjs.GameCode.GDCitySkylineObjects1= [];
gdjs.GameCode.GDCitySkylineObjects2= [];
gdjs.GameCode.GDCitySkylineObjects3= [];
gdjs.GameCode.GDCitySkylineObjects4= [];
gdjs.GameCode.GDCitySkylineObjects5= [];
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects1= [];
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects2= [];
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects3= [];
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects4= [];
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects5= [];
gdjs.GameCode.GDGUIBackGroundObjects1= [];
gdjs.GameCode.GDGUIBackGroundObjects2= [];
gdjs.GameCode.GDGUIBackGroundObjects3= [];
gdjs.GameCode.GDGUIBackGroundObjects4= [];
gdjs.GameCode.GDGUIBackGroundObjects5= [];


gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects = Hashtable.newFrom({"Block_1": gdjs.GameCode.GDBlock_95951Objects1, "Block_2": gdjs.GameCode.GDBlock_95952Objects1, "Block_3": gdjs.GameCode.GDBlock_95953Objects1});
gdjs.GameCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Block_1"), gdjs.GameCode.GDBlock_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block_2"), gdjs.GameCode.GDBlock_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block_3"), gdjs.GameCode.GDBlock_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.pickAllObjects(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12848300);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBlock_95951Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95952Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95953Objects1 */
{for(var i = 0, len = gdjs.GameCode.GDBlock_95951Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95951Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95951Objects1[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(6).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDBlock_95952Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95952Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95952Objects1[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(4).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDBlock_95953Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95953Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95953Objects1[i].getVariables().getFromIndex(0)).setNumber(runtimeScene.getScene().getVariables().getFromIndex(5).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDBlock_95951Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95951Objects1[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95951Objects1[i].getVariables().get("Health").getAsNumber() - 1);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95952Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95952Objects1[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95952Objects1[i].getVariables().get("Health").getAsNumber() - 1);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95953Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95953Objects1[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95953Objects1[i].getVariables().get("Health").getAsNumber() - 1);
}
}
}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(6).setNumber(gdjs.randomInRange(1, 3));
}
{runtimeScene.getScene().getVariables().getFromIndex(4).setNumber(gdjs.randomInRange(1, 3));
}
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber(gdjs.randomInRange(1, 3));
}
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "BrickLayout" + gdjs.evtTools.common.toString(gdjs.randomInRange(1, 5)), 0, 0, 0);
}

{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects = Hashtable.newFrom({"Home_Button": gdjs.GameCode.GDHome_9595ButtonObjects2});
gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12833532);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHome_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/select_003.ogg", false, 70, 100);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects = Hashtable.newFrom({"Home_Button": gdjs.GameCode.GDHome_9595ButtonObjects2});
gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12836460);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHome_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/select_003.ogg", false, 70, 100);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Menu", false);
}
}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndCard");
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects = Hashtable.newFrom({"Home_Button": gdjs.GameCode.GDHome_9595ButtonObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects2Objects = Hashtable.newFrom({"Replay_Button": gdjs.GameCode.GDReplay_9595ButtonObjects2});
gdjs.GameCode.eventsList5 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12840340);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDReplay_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDReplay_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/select_003.ogg", false, 70, 100);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects2Objects = Hashtable.newFrom({"Replay_Button": gdjs.GameCode.GDReplay_9595ButtonObjects2});
gdjs.GameCode.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12843316);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Home_Button"), gdjs.GameCode.GDHome_9595ButtonObjects2);
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(2);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/select_003.ogg", false, 70, 100);
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, gdjs.evtTools.runtimeScene.getSceneName(runtimeScene), false);
}
}

}


};gdjs.GameCode.eventsList7 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "EndCard");
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects1Objects = Hashtable.newFrom({"Replay_Button": gdjs.GameCode.GDReplay_9595ButtonObjects1});
gdjs.GameCode.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Card_Title"), gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2);
gdjs.copyArray(runtimeScene.getObjects("ScoreLabel"), gdjs.GameCode.GDScoreLabelObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartCard_Sub_title"), gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2);
gdjs.copyArray(runtimeScene.getObjects("StartCard_title"), gdjs.GameCode.GDStartCard_9595titleObjects2);
{for(var i = 0, len = gdjs.GameCode.GDScoreLabelObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreLabelObjects2[i].setShadow("41;49;72", 5, 0, -100);
}
}
{for(var i = 0, len = gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2[i].setShadow("41;49;72", 5, 0, -100);
}
}
{for(var i = 0, len = gdjs.GameCode.GDStartCard_9595titleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDStartCard_9595titleObjects2[i].setShadow("41;49;72", 5, 0, -100);
}
}
{for(var i = 0, len = gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2[i].setShadow("41;49;72", 5, 0, -100);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("ScoreLabel"), gdjs.GameCode.GDScoreLabelObjects2);
{for(var i = 0, len = gdjs.GameCode.GDScoreLabelObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreLabelObjects2[i].getBehavior("Text").setText("Score: " + runtimeScene.getScene().getVariables().getFromIndex(1).getAsString());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home_Button"), gdjs.GameCode.GDHome_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDHome_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDHome_9595ButtonObjects2[i].getVariableString(gdjs.GameCode.GDHome_9595ButtonObjects2[i].getVariables().getFromIndex(0)) == "GUI" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDHome_9595ButtonObjects2[k] = gdjs.GameCode.GDHome_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDHome_9595ButtonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHome_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}

{ //Subevents
gdjs.GameCode.eventsList2(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home_Button"), gdjs.GameCode.GDHome_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDHome_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDHome_9595ButtonObjects2[i].getVariableString(gdjs.GameCode.GDHome_9595ButtonObjects2[i].getVariables().getFromIndex(0)) == "EndCard" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDHome_9595ButtonObjects2[k] = gdjs.GameCode.GDHome_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDHome_9595ButtonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHome_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}

{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Home_Button"), gdjs.GameCode.GDHome_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDHome_95959595ButtonObjects2Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDHome_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDHome_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDHome_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Replay_Button"), gdjs.GameCode.GDReplay_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDReplay_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getVariableString(gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getVariables().getFromIndex(0)) == "GUI" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDReplay_9595ButtonObjects2[k] = gdjs.GameCode.GDReplay_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDReplay_9595ButtonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDReplay_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDReplay_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}

{ //Subevents
gdjs.GameCode.eventsList5(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Replay_Button"), gdjs.GameCode.GDReplay_9595ButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects2Objects, runtimeScene, true, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDReplay_9595ButtonObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getVariableString(gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getVariables().getFromIndex(0)) == "EndCard" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDReplay_9595ButtonObjects2[k] = gdjs.GameCode.GDReplay_9595ButtonObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDReplay_9595ButtonObjects2.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDReplay_9595ButtonObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDReplay_9595ButtonObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDReplay_9595ButtonObjects2[i].getBehavior("Animation").setAnimationIndex(1);
}
}

{ //Subevents
gdjs.GameCode.eventsList7(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Replay_Button"), gdjs.GameCode.GDReplay_9595ButtonObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDReplay_95959595ButtonObjects1Objects, runtimeScene, true, true);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDReplay_9595ButtonObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDReplay_9595ButtonObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDReplay_9595ButtonObjects1[i].getBehavior("Animation").setAnimationIndex(0);
}
}
}

}


};gdjs.GameCode.eventsList9 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects3);
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects3[i].getBehavior("TopDownMovement").simulateLeftKey();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects2);
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects2[i].getBehavior("TopDownMovement").simulateRightKey();
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects = Hashtable.newFrom({"Paddle": gdjs.GameCode.GDPaddleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects = Hashtable.newFrom({"Barrier": gdjs.GameCode.GDBarrierObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects = Hashtable.newFrom({"Barrier": gdjs.GameCode.GDBarrierObjects2});
gdjs.GameCode.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "GamePlay");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
{isConditionTrue_1 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "NotStarted");
}
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList9(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.GameCode.GDBarrierObjects2);
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBarrierObjects2 */
/* Reuse gdjs.GameCode.GDPaddleObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects2[i].separateFromObjectsList(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects, false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() > 1.3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(1.3);
}
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects2[i].getBehavior("Scale").setScaleX(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 0.8);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber(0.8);
}
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects1[i].getBehavior("Scale").setScaleX(runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber());
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects = Hashtable.newFrom({"Paddle": gdjs.GameCode.GDPaddleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects = Hashtable.newFrom({"Paddle": gdjs.GameCode.GDPaddleObjects2});
gdjs.GameCode.eventsList11 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDBallObjects2, gdjs.GameCode.GDBallObjects3);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects3[i].getVariableNumber(gdjs.GameCode.GDBallObjects3[i].getVariables().getFromIndex(0)) >= 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBallObjects3[k] = gdjs.GameCode.GDBallObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects3.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects3 */
gdjs.copyArray(runtimeScene.getObjects("OnFireParticle"), gdjs.GameCode.GDOnFireParticleObjects3);
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects3[i].deleteFromScene(runtimeScene);
}
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects3[i].returnVariable(gdjs.GameCode.GDBallObjects3[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDBallObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].returnVariable(gdjs.GameCode.GDBallObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects = Hashtable.newFrom({"Barrier": gdjs.GameCode.GDBarrierObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects = Hashtable.newFrom({"Barrier": gdjs.GameCode.GDBarrierObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects = Hashtable.newFrom({"Block_1": gdjs.GameCode.GDBlock_95951Objects1, "Block_2": gdjs.GameCode.GDBlock_95952Objects1, "Block_3": gdjs.GameCode.GDBlock_95953Objects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects = Hashtable.newFrom({"Block_1": gdjs.GameCode.GDBlock_95951Objects1, "Block_2": gdjs.GameCode.GDBlock_95952Objects1, "Block_3": gdjs.GameCode.GDBlock_95953Objects1});
gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects3);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects3);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects3);

{for(var i = 0, len = gdjs.GameCode.GDBlock_95951Objects3.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95951Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95951Objects3[i].getVariables().get("Health").getAsNumber() - 1);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95952Objects3.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95952Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95952Objects3[i].getVariables().get("Health").getAsNumber() - 1);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95953Objects3.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95953Objects3[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.GDBlock_95953Objects3[i].getVariables().get("Health").getAsNumber() - 1);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95951Objects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95951Objects2[i].getVariableNumber(gdjs.GameCode.GDBlock_95951Objects2[i].getVariables().get("Health")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95951Objects2[k] = gdjs.GameCode.GDBlock_95951Objects2[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95951Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95952Objects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95952Objects2[i].getVariableNumber(gdjs.GameCode.GDBlock_95952Objects2[i].getVariables().get("Health")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95952Objects2[k] = gdjs.GameCode.GDBlock_95952Objects2[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95952Objects2.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95953Objects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95953Objects2[i].getVariableNumber(gdjs.GameCode.GDBlock_95953Objects2[i].getVariables().get("Health")) <= 0 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95953Objects2[k] = gdjs.GameCode.GDBlock_95953Objects2[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95953Objects2.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBlock_95951Objects2 */
/* Reuse gdjs.GameCode.GDBlock_95952Objects2 */
/* Reuse gdjs.GameCode.GDBlock_95953Objects2 */
{for(var i = 0, len = gdjs.GameCode.GDBlock_95951Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95951Objects2[i].getBehavior("Tween").addObjectScaleTween("DestroyTween", 0, 0, "swingTo", 650, true, true);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95952Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95952Objects2[i].getBehavior("Tween").addObjectScaleTween("DestroyTween", 0, 0, "swingTo", 650, true, true);
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95953Objects2.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95953Objects2[i].getBehavior("Tween").addObjectScaleTween("DestroyTween", 0, 0, "swingTo", 650, true, true);
}
}
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects1Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects1Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects1});
gdjs.GameCode.eventsList13 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);

gdjs.GameCode.GDPowerUpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects, (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].addPolarForce(90, 300, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 1.3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);

gdjs.GameCode.GDPowerUpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects, (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].addPolarForce(90, 300, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() > 0.8);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);

gdjs.GameCode.GDPowerUpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects, (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].addPolarForce(90, 300, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < 1.3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);

gdjs.GameCode.GDPowerUpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects, (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].addPolarForce(90, 300, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 0.8);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBlock_95951Objects1, gdjs.GameCode.GDBlock_95951Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95952Objects1, gdjs.GameCode.GDBlock_95952Objects2);

gdjs.copyArray(gdjs.GameCode.GDBlock_95953Objects1, gdjs.GameCode.GDBlock_95953Objects2);

gdjs.GameCode.GDPowerUpObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects2Objects, (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects2.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects2.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects2[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects2[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects2[i].addPolarForce(90, 300, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects1Objects) < 5;
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBlock_95951Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95952Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95953Objects1 */
gdjs.GameCode.GDPowerUpObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects1Objects, (( gdjs.GameCode.GDBlock_95953Objects1.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects1.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects1.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects1[0].getPointX("")) :gdjs.GameCode.GDBlock_95952Objects1[0].getPointX("")) :gdjs.GameCode.GDBlock_95953Objects1[0].getPointX("")), (( gdjs.GameCode.GDBlock_95953Objects1.length === 0 ) ? (( gdjs.GameCode.GDBlock_95952Objects1.length === 0 ) ? (( gdjs.GameCode.GDBlock_95951Objects1.length === 0 ) ? 0 :gdjs.GameCode.GDBlock_95951Objects1[0].getPointY("")) :gdjs.GameCode.GDBlock_95952Objects1[0].getPointY("")) :gdjs.GameCode.GDBlock_95953Objects1[0].getPointY("")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects1[i].getBehavior("Animation").setAnimationIndex(gdjs.GameCode.localVariables[0].getFromIndex(0).getAsNumber());
}
}
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects1[i].addPolarForce(90, 300, 1);
}
}
}

}


};gdjs.GameCode.eventsList14 = function(runtimeScene) {

{


{
const variables = new gdjs.VariablesContainer();
{
const variable = new gdjs.Variable();
variable.setNumber(0);
variables._declare("PowerUpDrop", variable);
}
gdjs.GameCode.localVariables.push(variables);
}
let isConditionTrue_0 = false;
{
{gdjs.GameCode.localVariables[0].getFromIndex(0).setNumber(gdjs.randomInRange(0, 12));
}

{ //Subevents
gdjs.GameCode.eventsList13(runtimeScene);} //End of subevents
}
gdjs.GameCode.localVariables.pop();

}


};gdjs.GameCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameCode.eventsList12(runtimeScene);
}


{


gdjs.GameCode.eventsList14(runtimeScene);
}


};gdjs.GameCode.eventsList16 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12477180);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects2 */
/* Reuse gdjs.GameCode.GDPaddleObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("BatBounce").BounceOff(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects2Objects, null);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/impactSoft_medium_004.ogg", false, 70, 1);
}

{ //Subevents
gdjs.GameCode.eventsList11(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.GameCode.GDBarrierObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12480916);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects2 */
/* Reuse gdjs.GameCode.GDBarrierObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Bounce").BounceOff(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBarrierObjects2Objects, null);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/impactSoft_medium_004.ogg", false, 70, 1);
}
}

}


{

gdjs.GameCode.GDBallObjects2.length = 0;


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{gdjs.GameCode.GDBallObjects2_1final.length = 0;
let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects3);
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects3[i].isTotalForceAngleAround(0, 5) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDBallObjects3[k] = gdjs.GameCode.GDBallObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDBallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDBallObjects2_1final.indexOf(gdjs.GameCode.GDBallObjects3[j]) === -1 )
            gdjs.GameCode.GDBallObjects2_1final.push(gdjs.GameCode.GDBallObjects3[j]);
    }
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects3);
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects3.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects3[i].isTotalForceAngleAround(180, 5) ) {
        isConditionTrue_1 = true;
        gdjs.GameCode.GDBallObjects3[k] = gdjs.GameCode.GDBallObjects3[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects3.length = k;
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
    for (let j = 0, jLen = gdjs.GameCode.GDBallObjects3.length; j < jLen ; ++j) {
        if ( gdjs.GameCode.GDBallObjects2_1final.indexOf(gdjs.GameCode.GDBallObjects3[j]) === -1 )
            gdjs.GameCode.GDBallObjects2_1final.push(gdjs.GameCode.GDBallObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.GameCode.GDBallObjects2_1final, gdjs.GameCode.GDBallObjects2);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].clearForces();
}
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].addPolarForce(gdjs.randomInRange(208, 248), 560, 1);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 1.3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1.3);
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Scale").setScale(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < 0.8);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0.8);
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Scale").setScale(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Block_1"), gdjs.GameCode.GDBlock_95951Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block_2"), gdjs.GameCode.GDBlock_95952Objects1);
gdjs.copyArray(runtimeScene.getObjects("Block_3"), gdjs.GameCode.GDBlock_95953Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95951Objects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95951Objects1[i].getBehavior("Scale").getScaleY() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95951Objects1[k] = gdjs.GameCode.GDBlock_95951Objects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95951Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95952Objects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95952Objects1[i].getBehavior("Scale").getScaleY() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95952Objects1[k] = gdjs.GameCode.GDBlock_95952Objects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95952Objects1.length = k;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBlock_95953Objects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBlock_95953Objects1[i].getBehavior("Scale").getScaleY() == 1 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBlock_95953Objects1[k] = gdjs.GameCode.GDBlock_95953Objects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBlock_95953Objects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12486740);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects1 */
/* Reuse gdjs.GameCode.GDBlock_95951Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95952Objects1 */
/* Reuse gdjs.GameCode.GDBlock_95953Objects1 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects1[i].getBehavior("Bounce").BounceOff(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects1ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects1Objects, null);
}
}
{for(var i = 0, len = gdjs.GameCode.GDBlock_95951Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95951Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95951Objects1[i].getVariables().get("Health")).sub(((gdjs.GameCode.GDBallObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDBallObjects1[0].getVariables()).getFromIndex(1).getAsNumber());
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95952Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95952Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95952Objects1[i].getVariables().get("Health")).sub(((gdjs.GameCode.GDBallObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDBallObjects1[0].getVariables()).getFromIndex(1).getAsNumber());
}
for(var i = 0, len = gdjs.GameCode.GDBlock_95953Objects1.length ;i < len;++i) {
    gdjs.GameCode.GDBlock_95953Objects1[i].returnVariable(gdjs.GameCode.GDBlock_95953Objects1[i].getVariables().get("Health")).sub(((gdjs.GameCode.GDBallObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDBallObjects1[0].getVariables()).getFromIndex(1).getAsNumber());
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).add(10);
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects1[i].returnVariable(gdjs.GameCode.GDBallObjects1[i].getVariables().getFromIndex(0)).add(1);
}
}
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/impactSoft_medium_004.ogg", false, 70, 1);
}

{ //Subevents
gdjs.GameCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects1Objects = Hashtable.newFrom({"Paddle": gdjs.GameCode.GDPaddleObjects1});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects1Objects = Hashtable.newFrom({"PowerUp": gdjs.GameCode.GDPowerUpObjects1});
gdjs.GameCode.mapOfEmptyGDBallObjects = Hashtable.newFrom({"Ball": []});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects2});
gdjs.GameCode.eventsList17 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(gdjs.GameCode.GDPaddleObjects1, gdjs.GameCode.GDPaddleObjects2);

/* Reuse gdjs.GameCode.GDPowerUpObjects2 */
gdjs.GameCode.GDBallObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects, (( gdjs.GameCode.GDPowerUpObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPowerUpObjects2[0].getCenterXInScene()), (( gdjs.GameCode.GDPowerUpObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDPowerUpObjects2[0].getCenterYInScene()), "");
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].addForceTowardObject((gdjs.GameCode.GDPaddleObjects2.length !== 0 ? gdjs.GameCode.GDPaddleObjects2[0] : null), 400 - (gdjs.GameCode.GDBallObjects2[i].getAverageForce().getLength()), 1);
}
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Scale").setScale(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}
}

}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "ExtraLife" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() < 3);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(7).add(1);
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "BiggerPaddle" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() < 1.3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDPaddleObjects1, gdjs.GameCode.GDPaddleObjects2);

{runtimeScene.getScene().getVariables().getFromIndex(3).add(0.3);
}
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects2[i].getBehavior("Tween").addObjectScaleXTween("PaddleScaleUp", runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "linear", 500, false, true);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "SmallerPaddle" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber() > 0.8);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDPaddleObjects1, gdjs.GameCode.GDPaddleObjects2);

{runtimeScene.getScene().getVariables().getFromIndex(3).sub(0.3);
}
{for(var i = 0, len = gdjs.GameCode.GDPaddleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDPaddleObjects2[i].getBehavior("Tween").addObjectScaleXTween("PaddleScaleDown", runtimeScene.getScene().getVariables().getFromIndex(3).getAsNumber(), "linear", 500, false, true);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "BiggerBall" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() < 1.3);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).add(0.3);
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Tween").addObjectScaleTween("BallScaleUp", runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), "linear", 500, false, true);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "SmallerBall" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber() > 0.8);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(2).sub(0.3);
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].getBehavior("Tween").addObjectScaleTween("BallScaleDown", runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), "linear", 500, false, true);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDPowerUpObjects1, gdjs.GameCode.GDPowerUpObjects2);


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDPowerUpObjects2.length;i<l;++i) {
    if ( gdjs.GameCode.GDPowerUpObjects2[i].getBehavior("Animation").getAnimationName() == "MultiBall" ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDPowerUpObjects2[k] = gdjs.GameCode.GDPowerUpObjects2[i];
        ++k;
    }
}
gdjs.GameCode.GDPowerUpObjects2.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDBallObjects) < 5;
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList17(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDPowerUpObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDPowerUpObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDPowerUpObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects1);
gdjs.copyArray(runtimeScene.getObjects("PowerUp"), gdjs.GameCode.GDPowerUpObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPaddleObjects1Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDPowerUpObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12503188);
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.sound.playMusic(runtimeScene, "Assets/impactMining_000.ogg", false, 70, 1);
}

{ //Subevents
gdjs.GameCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDOnFireParticleObjects2Objects = Hashtable.newFrom({"OnFireParticle": gdjs.GameCode.GDOnFireParticleObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects2});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects2ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects2ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects2Objects = Hashtable.newFrom({"Block_1": gdjs.GameCode.GDBlock_95951Objects2, "Block_2": gdjs.GameCode.GDBlock_95952Objects2, "Block_3": gdjs.GameCode.GDBlock_95953Objects2});
gdjs.GameCode.eventsList20 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12516892);
}
if (isConditionTrue_0) {
gdjs.copyArray(gdjs.GameCode.GDBallObjects1, gdjs.GameCode.GDBallObjects2);

gdjs.GameCode.GDOnFireParticleObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDOnFireParticleObjects2Objects, (( gdjs.GameCode.GDBallObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects2[0].getPointX("Center")), (( gdjs.GameCode.GDBallObjects2.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects2[0].getPointY("Center")), "");
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].returnVariable(gdjs.GameCode.GDBallObjects2[i].getVariables().getFromIndex(1)).setNumber(2);
}
}
}

}


{

gdjs.copyArray(gdjs.GameCode.GDBallObjects1, gdjs.GameCode.GDBallObjects2);

gdjs.copyArray(runtimeScene.getObjects("Block_1"), gdjs.GameCode.GDBlock_95951Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block_2"), gdjs.GameCode.GDBlock_95952Objects2);
gdjs.copyArray(runtimeScene.getObjects("Block_3"), gdjs.GameCode.GDBlock_95953Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects2Objects, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBlock_959595951Objects2ObjectsGDgdjs_9546GameCode_9546GDBlock_959595952Objects2ObjectsGDgdjs_9546GameCode_9546GDBlock_959595953Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12518108);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects2 */
gdjs.copyArray(runtimeScene.getObjects("OnFireParticle"), gdjs.GameCode.GDOnFireParticleObjects2);
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects2[i].setParticleSize1(gdjs.GameCode.GDOnFireParticleObjects2[i].getParticleSize1() + (2));
}
}
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects2[i].setParticleSize2(gdjs.GameCode.GDOnFireParticleObjects2[i].getParticleSize2() + (2));
}
}
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects2[i].setEmitterForceMin(gdjs.GameCode.GDOnFireParticleObjects2[i].getEmitterForceMin() + (((gdjs.GameCode.GDBallObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameCode.GDBallObjects2[0].getVariables()).getFromIndex(2).getAsNumber() * 10));
}
}
}

}


{


let isConditionTrue_0 = false;
{
/* Reuse gdjs.GameCode.GDBallObjects1 */
gdjs.copyArray(runtimeScene.getObjects("OnFireParticle"), gdjs.GameCode.GDOnFireParticleObjects1);
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects1[i].setAngle((( gdjs.GameCode.GDBallObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects1[0].getAverageForce().getAngle()) + 180);
}
}
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects1[i].setPosition((( gdjs.GameCode.GDBallObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects1[0].getPointX("Center")),(( gdjs.GameCode.GDBallObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects1[0].getPointY("Center")));
}
}
}

}


};gdjs.GameCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects1[i].getVariableNumber(gdjs.GameCode.GDBallObjects1[i].getVariables().getFromIndex(0)) >= 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBallObjects1[k] = gdjs.GameCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfEmptyGDBallObjects = Hashtable.newFrom({"Ball": []});
gdjs.GameCode.mapOfEmptyGDBallObjects = Hashtable.newFrom({"Ball": []});
gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects3Objects = Hashtable.newFrom({"Ball": gdjs.GameCode.GDBallObjects3});
gdjs.GameCode.eventsList22 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDBallObjects) == 0;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects3);
gdjs.GameCode.GDBallObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene(runtimeScene, gdjs.GameCode.mapOfGDgdjs_9546GameCode_9546GDBallObjects3Objects, (( gdjs.GameCode.GDPaddleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleObjects3[0].getPointX("Center")), (( gdjs.GameCode.GDPaddleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleObjects3[0].getPointY("Center")) - 30 - runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber(), "");
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects3[i].getBehavior("Scale").setScale(runtimeScene.getScene().getVariables().getFromIndex(2).getAsNumber());
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects3);
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects3);
{for(var i = 0, len = gdjs.GameCode.GDBallObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects3[i].setPosition((( gdjs.GameCode.GDPaddleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleObjects3[0].getPointX("Center")),(( gdjs.GameCode.GDPaddleObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleObjects3[0].getPointY("Center")) - 30 - (gdjs.GameCode.GDBallObjects3[i].getHeight()));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{let isConditionTrue_1 = false;
isConditionTrue_0 = false;
{
isConditionTrue_1 = gdjs.evtTools.input.wasKeyReleased(runtimeScene, "Space");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
isConditionTrue_1 = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
if(isConditionTrue_1) {
    isConditionTrue_0 = true;
}
}
{
}
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12526692);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects2);
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects2);
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].clearForces();
}
}
{for(var i = 0, len = gdjs.GameCode.GDBallObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects2[i].addForceTowardObject((gdjs.GameCode.GDPaddleObjects2.length !== 0 ? gdjs.GameCode.GDPaddleObjects2[0] : null), 400 - (gdjs.GameCode.GDBallObjects2[i].getAverageForce().getLength()), 1);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("GamePlay");
}
}

}


};gdjs.GameCode.eventsList23 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "GamePlay");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDBallObjects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() > 0);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("NotStarted");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "NotStarted");
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "PreStartCard");
}

{ //Subevents
gdjs.GameCode.eventsList22(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfEmptyGDBlock_95951ObjectsEmptyGDBlock_95952ObjectsEmptyGDBlock_95953Objects = Hashtable.newFrom({"Block_1": [], "Block_2": [], "Block_3": []});
gdjs.GameCode.eventsList24 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12455404);
}
if (isConditionTrue_0) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "PreStartCard");
}
{gdjs.evtTools.camera.showLayer(runtimeScene, "GUI");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12532372);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Lost");
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.getSceneInstancesCount(runtimeScene, gdjs.GameCode.mapOfEmptyGDBlock_95951ObjectsEmptyGDBlock_95952ObjectsEmptyGDBlock_95953Objects) == 0;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12533844);
}
}
if (isConditionTrue_0) {
{runtimeScene.getScene().getVariables().getFromIndex(0).setString("Won");
}
}

}


};gdjs.GameCode.eventsList25 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() != "GamePlay");
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Backdrop"), gdjs.GameCode.GDBackdropObjects3);
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects3);
{for(var i = 0, len = gdjs.GameCode.GDBallObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects3[i].clearForces();
}
}
{gdjs.evtTools.camera.hideLayer(runtimeScene, "GUI");
}
{for(var i = 0, len = gdjs.GameCode.GDBackdropObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBackdropObjects3[i].drawRectangle(0, 0, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene), gdjs.evtTools.window.getGameResolutionHeight(runtimeScene));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "GamePlay");
}
if (isConditionTrue_0) {

{ //Subevents
gdjs.GameCode.eventsList24(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList26 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "Lost");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12534820);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Card_Title"), gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2);
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndCard");
}
{for(var i = 0, len = gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2[i].getBehavior("Text").setText("SYGNAL UTRACONY");
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsString() == "Won");
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12535716);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("End_Card_Title"), gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1);
{gdjs.evtTools.camera.showLayer(runtimeScene, "EndCard");
}
{for(var i = 0, len = gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1[i].getBehavior("Text").setText("LEVEL ROZBITY");
}
}
}

}


};gdjs.GameCode.eventsList27 = function(runtimeScene) {

{


gdjs.GameCode.eventsList23(runtimeScene);
}


{


gdjs.GameCode.eventsList25(runtimeScene);
}


{


gdjs.GameCode.eventsList26(runtimeScene);
}


};gdjs.GameCode.eventsList28 = function(runtimeScene) {

{

/* Reuse gdjs.GameCode.GDBallObjects1 */

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects1[i].getVariableNumber(gdjs.GameCode.GDBallObjects1[i].getVariables().getFromIndex(0)) >= 5 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBallObjects1[k] = gdjs.GameCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("OnFireParticle"), gdjs.GameCode.GDOnFireParticleObjects1);
{for(var i = 0, len = gdjs.GameCode.GDOnFireParticleObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDOnFireParticleObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.GameCode.eventsList29 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("Life_Counter"), gdjs.GameCode.GDLife_9595CounterObjects2);
{for(var i = 0, len = gdjs.GameCode.GDLife_9595CounterObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDLife_9595CounterObjects2[i].getBehavior("Animation").setAnimationIndex(runtimeScene.getScene().getVariables().getFromIndex(7).getAsNumber());
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("PaddleLine"), gdjs.GameCode.GDPaddleLineObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.GameCode.GDBallObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDBallObjects1[i].getY() > (( gdjs.GameCode.GDPaddleLineObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleLineObjects1[0].getPointY("")) + 20 ) {
        isConditionTrue_0 = true;
        gdjs.GameCode.GDBallObjects1[k] = gdjs.GameCode.GDBallObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDBallObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(12539300);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.GameCode.GDBallObjects1 */
{for(var i = 0, len = gdjs.GameCode.GDBallObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBallObjects1[i].deleteFromScene(runtimeScene);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(7).sub(1);
}

{ //Subevents
gdjs.GameCode.eventsList28(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.userFunc0xaf8488 = function GDJSInlineCode(runtimeScene) {
"use strict";
// Breakout Lab hooks (injected into Game JsCode). Restart is scene replace, not a second Game instance.
(function (runtimeScene) {
  var BO_BOARDS = {"balanced-mid":{"id":"balanced-mid","columns":4,"rows":5,"cells":[[{"hp":1},{"hp":2},{"hp":3},{"hp":3}],[null,{"hp":2},{"hp":3},{"hp":3}],[null,{"hp":2},{"hp":3},{"hp":3}],[null,null,{"hp":3},{"hp":3}],[null,null,null,{"hp":3}]],"brickCount":13,"bonusSlots":1,"ballSpeed":420,"paddleWidthScale":0.9937499999999999,"signature":"7c837642c177a8b3c3f939981df40212bb92c83519704c326c721dc3a4186db6"},"dense-high":{"id":"dense-high","columns":8,"rows":5,"cells":[[{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3}],[{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3}],[{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3}],[{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3}],[{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3},{"hp":3}]],"brickCount":40,"bonusSlots":8,"ballSpeed":473,"paddleWidthScale":0.9112499999999999,"signature":"18ae1f83c1a9a6e2398bb5ee1f3cc7cb425326b7eba84d8f5e1be20e4838b485"},"met-vase-open-data":{"id":"met-vase-open-data","columns":11,"rows":5,"cells":[[{"hp":2},{"hp":2},{"hp":3},{"hp":1},{"hp":2},{"hp":2},{"hp":1},{"hp":3},{"hp":3},null,{"hp":3}],[{"hp":2},{"hp":2},{"hp":3},null,{"hp":2},{"hp":2},null,{"hp":3},{"hp":3},null,{"hp":3}],[{"hp":2},null,{"hp":3},null,null,{"hp":2},null,{"hp":3},{"hp":3},null,{"hp":3}],[null,null,{"hp":3},null,null,null,null,{"hp":3},{"hp":3},null,{"hp":3}],[null,null,null,null,null,null,null,{"hp":3},null,null,{"hp":3}]],"brickCount":30,"bonusSlots":2,"ballSpeed":407,"paddleWidthScale":1.0136363636363637,"signature":"f5f29bf3a3e6ef8e40e701dc62df37e5a1f655451a5115feade0e30dd72efa3d"},"mixed-corridor":{"id":"mixed-corridor","columns":6,"rows":5,"cells":[[null,{"hp":3},null,{"hp":3},null,{"hp":3}],[null,{"hp":3},null,{"hp":3},null,{"hp":3}],[null,{"hp":3},null,{"hp":3},null,{"hp":3}],[null,{"hp":3},null,{"hp":3},null,{"hp":3}],[null,{"hp":3},null,{"hp":3},null,{"hp":3}]],"brickCount":15,"bonusSlots":1,"ballSpeed":400,"paddleWidthScale":1.0254166666666666,"signature":"3d50c084c6cd0f3c337432117db2e8878e383c646e9387312f415f58c702807e"},"mixed-spike":{"id":"mixed-spike","columns":6,"rows":5,"cells":[[null,null,{"hp":3},null,null,{"hp":2}],[null,null,{"hp":3},null,null,{"hp":2}],[null,null,{"hp":3},null,null,{"hp":2}],[null,null,{"hp":3},null,null,null],[null,null,{"hp":3},null,null,null]],"brickCount":8,"bonusSlots":1,"ballSpeed":360,"paddleWidthScale":1.0875,"signature":"d6511ad964d86d674376d374504b123a617ab7d691799175755a4f31ed7cbf52"},"sparse-low":{"id":"sparse-low","columns":6,"rows":5,"cells":[[{"hp":1},{"hp":1},{"hp":1},{"hp":1},{"hp":1},{"hp":1}],[null,null,null,null,null,null],[null,null,null,null,null,null],[null,null,null,null,null,null],[null,null,null,null,null,null]],"brickCount":6,"bonusSlots":0,"ballSpeed":354,"paddleWidthScale":1.0975,"signature":"65946b7f6c78a26942b27952ec4d3f07798273627ab0e2c085c9aef14e1130e3"}};
  var BO_CITY_BOARDS = {"balanced-mid":{"id":"balanced-mid","columns":8,"rows":5,"cells":[[{"hp":3,"family":"podmioty"},{"hp":2,"family":"zielen"},null,{"hp":2,"family":"zielen"},null,null,null,null],[{"hp":2,"family":"gestosc"},{"hp":2,"family":"zielen"},null,null,null,null,{"hp":2,"family":"zielen"},{"hp":3,"family":"podmioty"}],[null,null,null,null,{"hp":2,"family":"zielen"},null,{"hp":3,"family":"podmioty"},{"hp":2,"family":"zabudowa"}],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null]],"brickCount":10,"mapping":"city-breaker-v1","paddleWidthScale":0.9550000000000001,"debug":{"rawValues":[50,50,50,50],"playable":{"density":50,"forest":50,"dwellings":50,"entities":50},"populationDensity":{"occupyThreshold":50,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[2,5],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":3,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":2,"clusterStride":4,"note":"higher → tougher / clustered HP"}},"signature":"da07a685159ad738ff9bc7db1b23654c9001b258682a94cd6f625e259b6cdea4"},"dense-spike":{"id":"dense-spike","columns":8,"rows":5,"cells":[[{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,null],[null,null,null,null,null,null,null,null]],"brickCount":28,"mapping":"city-breaker-v1","paddleWidthScale":0.8450000000000001,"debug":{"rawValues":[94,8,88,72],"playable":{"density":94,"forest":8,"dwellings":88,"entities":72},"populationDensity":{"occupyThreshold":94,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":4,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":3,"clusterStride":2,"note":"higher → tougher / clustered HP"}},"signature":"8336f9ea3e2d7dcfd6572086be52fc0713c85f4fa564b31775c8e25f7a840a9c"},"green-open":{"id":"green-open","columns":8,"rows":5,"cells":[[{"hp":1,"family":"zielen"},null,{"hp":1,"family":"zielen"},{"hp":1,"family":"zielen"},null,{"hp":1,"family":"zielen"},null,{"hp":1,"family":"zielen"}],[{"hp":1,"family":"zielen"},null,{"hp":1,"family":"zielen"},null,null,null,null,{"hp":1,"family":"zielen"}],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null]],"brickCount":8,"mapping":"city-breaker-v1","paddleWidthScale":1.0250000000000001,"debug":{"rawValues":[18,86,28,22],"playable":{"density":22,"forest":86,"dwellings":28,"entities":22},"populationDensity":{"occupyThreshold":22,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[1,4,6],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":2,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":1,"clusterStride":0,"note":"higher → tougher / clustered HP"}},"signature":"48ee1800c9c22fd6e2b62c989c6d607b0f531f648045ffa07fa9026b689266bb"},"high-edge":{"id":"high-edge","columns":8,"rows":5,"cells":[[{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"}],[{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"},null,{"hp":3,"family":"podmioty"}],[null,null,null,null,null,null,null,null]],"brickCount":20,"mapping":"city-breaker-v1","paddleWidthScale":0.8300000000000001,"debug":{"rawValues":[100,100,100,100],"playable":{"density":100,"forest":100,"dwellings":100,"entities":100},"populationDensity":{"occupyThreshold":100,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[1,4,6],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":4,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":3,"clusterStride":2,"note":"higher → tougher / clustered HP"}},"signature":"39c7df387246cfca153c386d25360b02675a9ec1f945b47a4560a567069c3c2f"},"low-edge":{"id":"low-edge","columns":8,"rows":5,"cells":[[{"hp":1,"family":"gestosc"},{"hp":1,"family":"gestosc"},{"hp":1,"family":"gestosc"},{"hp":1,"family":"gestosc"},{"hp":1,"family":"gestosc"},{"hp":1,"family":"gestosc"},null,null],[null,null,null,null,null,null,{"hp":1,"family":"zabudowa"},{"hp":1,"family":"zabudowa"}],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null]],"brickCount":8,"mapping":"city-breaker-v1","paddleWidthScale":1.0250000000000001,"debug":{"rawValues":[0,0,0,0],"playable":{"density":22,"forest":0,"dwellings":20,"entities":0},"populationDensity":{"occupyThreshold":22,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":2,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":1,"clusterStride":0,"note":"higher → tougher / clustered HP"}},"signature":"e048f33feffd2d2355e4f9c01e5eb94445fa1aff64bd496b9c4a9ffa57b2a5c0"},"mixed-spike":{"id":"mixed-spike","columns":8,"rows":5,"cells":[[{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null,null,null,null,null],[{"hp":3,"family":"podmioty"},null,null,null,null,null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"}],[null,null,null,null,{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},{"hp":3,"family":"podmioty"},null],[null,null,null,null,null,null,null,null],[null,null,null,null,null,null,null,null]],"brickCount":9,"mapping":"city-breaker-v1","paddleWidthScale":0.9750000000000001,"debug":{"rawValues":[42,24,48,96],"playable":{"density":42,"forest":24,"dwellings":48,"entities":96},"populationDensity":{"occupyThreshold":42,"note":"higher → more occupied cells"},"forestCover":{"corridorColumns":[3],"note":"higher → more vertical openings"},"dwellingsPer1000":{"brickRows":3,"note":"higher → more vertical mass (row 4 always clear)"},"entitiesPer1000":{"hp":3,"clusterStride":2,"note":"higher → tougher / clustered HP"}},"signature":"2fcf2c3a6d2b57dd53e5eeb73a3d6f9d1a3b5df2863e91fe0cb677b21790bae3"}};
  var BO_MET_RECORDS = [{"id":205482,"title":"Vase (vase Indien)","year":1760,"image":"https://images.metmuseum.org/CRDImages/es/web-large/ES5991.jpg","url":"https://www.metmuseum.org/art/collection/search/205482"},{"id":208152,"title":"Vase","year":1820,"image":"https://images.metmuseum.org/CRDImages/es/web-large/DP156496.jpg","url":"https://www.metmuseum.org/art/collection/search/208152"},{"id":205922,"title":"Vase","year":1730,"image":"https://images.metmuseum.org/CRDImages/es/web-large/DP168387.jpg","url":"https://www.metmuseum.org/art/collection/search/205922"},{"id":9316,"title":"Vase","year":1851,"image":"https://images.metmuseum.org/CRDImages/ad/web-large/ADA5445.jpg","url":"https://www.metmuseum.org/art/collection/search/9316"},{"id":9284,"title":"Vase","year":1830,"image":"https://images.metmuseum.org/CRDImages/ad/web-large/140930.jpg","url":"https://www.metmuseum.org/art/collection/search/9284"},{"id":198685,"title":"Vase","year":1756,"image":"https://images.metmuseum.org/CRDImages/es/web-large/DP-15275-023.jpg","url":"https://www.metmuseum.org/art/collection/search/198685"},{"id":9563,"title":"Vase","year":1857,"image":"https://images.metmuseum.org/CRDImages/ad/web-large/201886.jpg","url":"https://www.metmuseum.org/art/collection/search/9563"},{"id":249072,"title":"Vase","year":-900,"image":"https://images.metmuseum.org/CRDImages/gr/web-large/LC-16_75_3.jpg","url":"https://www.metmuseum.org/art/collection/search/249072"},{"id":244836,"title":"Vase","year":-580,"image":"https://images.metmuseum.org/CRDImages/gr/web-large/sf75411.jpg","url":"https://www.metmuseum.org/art/collection/search/244836"},{"id":9227,"title":"Vase","year":1886,"image":"https://images.metmuseum.org/CRDImages/ad/web-large/174352.jpg","url":"https://www.metmuseum.org/art/collection/search/9227"},{"id":250238,"title":"Vase","year":-670,"image":"https://images.metmuseum.org/CRDImages/gr/web-large/LC-17_194_1819.jpg","url":"https://www.metmuseum.org/art/collection/search/250238"}];

  function hideAll(name) {
    try {
      const list = runtimeScene.getObjects(name);
      for (let i = 0; i < list.length; i++) list[i].hide(true);
    } catch (eH) {}
  }
  if (!runtimeScene._boSessionInit) {
    runtimeScene._boSessionInit = true;
    try {
      runtimeScene.getScene().getVariables().get("Lifes").setNumber(3);
      runtimeScene.getScene().getVariables().get("Score").setNumber(0);
    } catch (eInit) {}
  }
  hideAll("Home_Button");

  try {
    const canvas = runtimeScene.getGame().getRenderer().getCanvas();
    if (canvas && canvas.style) canvas.style.touchAction = "none";
  } catch (eTouch) {}

  if (!runtimeScene._boBoardApplied) {
    runtimeScene._boBoardApplied = true;
    applyLabBoard(runtimeScene, BO_BOARDS, BO_CITY_BOARDS);
  }

  hideAll("StartCard_title");
  hideAll("StartCard_Sub_title");
  hideAll("ScoreLabel");
  hideAll("GUIBackGround");
  try {
    if (gdjs.evtTools.camera && typeof gdjs.evtTools.camera.hideLayer === "function") {
      gdjs.evtTools.camera.hideLayer(runtimeScene, "PreStartCard");
    }
  } catch (eLayer) {}

  let st = "";
  let score = 0;
  let lives = 0;
  try {
    st = runtimeScene.getScene().getVariables().get("GameState").getAsString();
  } catch (eSt) {}
  try {
    score = runtimeScene.getScene().getVariables().get("Score").getAsNumber();
  } catch (eSc) {}
  try {
    lives = runtimeScene.getScene().getVariables().get("Lifes").getAsNumber();
  } catch (eLf) {}
  updatePlonkuShell(st, score, lives);
  updateMuseumPanel(BO_MET_RECORDS);
  pulseHitJuice(runtimeScene, st);

  if (st === "NotStarted" || st === "GamePlay") {
    const pads = runtimeScene.getObjects("Paddle");
    if (pads.length) {
      const p = pads[0];
      const im = runtimeScene.getGame().getInputManager();
      const cx = im.getCursorX();
      const w = p.getWidth();
      const maxX = runtimeScene.getGame().getGameResolutionWidth() - w;
      let x = cx - w / 2;
      if (x < 0) x = 0;
      if (x > maxX) x = maxX;
      p.setX(x);
    }
  }

  if (typeof window !== "undefined") {
    window.__boSoftReset = function () {
      const game = window.__boGame;
      if (game && game.getSceneStack) game.getSceneStack().replace("Game", true);
      else gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", false);
    };
  }

  if (gdjs.evtTools.input.wasKeyJustPressed(runtimeScene, "R")) {
    gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Game", true);
  }

  function profileLabel(id) {
    const map = {
      "balanced-mid": "BALANS",
      "dense-spike": "GESTE MIASTO",
      "green-open": "ZIELONY OTWARTY",
      "mixed-spike": "SPIKE",
      "low-edge": "MINIMUM",
      "high-edge": "MAXIMUM",
    };
    return map[id] || "BALANS";
  }

  function pulseHitJuice(scene, gameState) {
    let bricks = 0;
    const names = ["Block_1", "Block_2", "Block_3"];
    for (let n = 0; n < names.length; n++) bricks += scene.getObjects(names[n]).length;
    if (scene._boBrickN == null) scene._boBrickN = bricks;
    if (typeof document === "undefined") {
      scene._boBrickN = bricks;
      return;
    }
    const stage = document.getElementById("cb-stage");
    if (gameState === "GamePlay" && bricks < scene._boBrickN) {
      if (stage) {
        stage.style.boxShadow = "inset 0 0 28px #C8FF00, inset 0 0 8px #FF2D95";
        setTimeout(function () {
          if (stage) stage.style.boxShadow = "";
        }, 90);
      }
      const hud = document.getElementById("bo-hud-chip");
      if (hud) {
        hud.style.background = "#C8FF00";
        hud.style.color = "#1A1410";
        setTimeout(function () {
          hud.style.background = "transparent";
          hud.style.color = "#00E5FF";
        }, 90);
      }
    }
    scene._boBrickN = bricks;
    if (gameState === "GamePlay") {
      const balls = scene.getObjects("Ball");
      const pads = scene.getObjects("Paddle");
      if (balls.length && pads.length) {
        const b = balls[0];
        const p = pads[0];
        const hit =
          b.getX() < p.getX() + p.getWidth() &&
          b.getX() + b.getWidth() > p.getX() &&
          b.getY() + b.getHeight() > p.getY() - 4 &&
          b.getY() < p.getY() + p.getHeight();
        if (hit && !scene._boPadFlash) {
          scene._boPadFlash = true;
          if (stage) stage.style.outline = "1px solid #00E5FF";
          setTimeout(function () {
            scene._boPadFlash = false;
            if (stage) stage.style.outline = "";
          }, 60);
        }
      }
    }
  }

  function startCityGenSequence(label) {
    if (typeof window === "undefined" || window.__boGenOnce) return;
    window.__boGenOnce = true;
    const gen = document.getElementById("cb-gen");
    if (!gen) return;
    const steps = ["ANALIZUJĘ DANE...", "BUDUJĘ LEVEL...", String(label || "BALANS") + ".DATA GOTOWE"];
    let i = 0;
    gen.style.display = "flex";
    function tick() {
      if (i < steps.length) {
        gen.innerHTML =
          "<div style=\"font-size:16px;\">" +
          steps[i] +
          "</div><div style=\"color:#00E5FF;font-size:11px;\">GĘSTOŚĆ · ZIELEŃ · ZABUDOWA · PODMIOTY</div>";
        i += 1;
        setTimeout(tick, 240);
      } else gen.style.display = "none";
    }
    tick();
  }

  function updatePlonkuShell(gameState, scoreVal, livesVal) {
    if (typeof document === "undefined") return;
    const pid = (typeof window !== "undefined" && window.__boBoardId) || "balanced-mid";
    const canvas = runtimeScene.getGame().getRenderer().getCanvas();
    if (!canvas || !canvas.parentElement) return;
    let root = document.getElementById("cb-window");
    if (!root) {
      try {
        document.documentElement.style.height = "100%";
        document.body.style.cssText = "margin:0;height:100%;background:#070B14;";
        const host = canvas.parentElement;
        host.style.cssText =
          "margin:0;height:100%;background:#070B14;display:flex;align-items:center;justify-content:center;padding:8px;box-sizing:border-box;";
        root = document.createElement("div");
        root.id = "cb-window";
        root.style.cssText =
          "position:relative;width:min(1200px,100%);height:min(100%,100dvh);display:flex;flex-direction:column;background:#0A1020;border:2px solid #C8FF00;box-shadow:0 0 0 1px #070B14, 8px 8px 0 #FF2D95;font-family:Verdana,Arial,sans-serif;color:#C8FF00;";
        root.innerHTML =
          '<div style="pointer-events:none;position:absolute;left:-2px;top:-2px;width:10px;height:10px;border-top:2px solid #00E5FF;border-left:2px solid #00E5FF;"></div>' +
          '<div style="pointer-events:none;position:absolute;right:-2px;top:-2px;width:10px;height:10px;border-top:2px solid #00E5FF;border-right:2px solid #00E5FF;"></div>' +
          '<div style="pointer-events:none;position:absolute;left:-2px;bottom:-2px;width:10px;height:10px;border-bottom:2px solid #00E5FF;border-left:2px solid #00E5FF;"></div>' +
          '<div style="pointer-events:none;position:absolute;right:-2px;bottom:-2px;width:10px;height:10px;border-bottom:2px solid #00E5FF;border-right:2px solid #00E5FF;"></div>' +
          '<div id="cb-titlebar" style="flex:0 0 28px;background:#D8D0C0;color:#1A1410;display:flex;align-items:center;justify-content:space-between;padding:0 10px;font-size:11px;letter-spacing:0.14em;border-bottom:2px solid #C8FF00;">' +
          "<span>CITYBRK.EXE — PUBLIC DATA / 2012 INTERNET ENERGY</span><span style=\"border:1px solid #1A1410;padding:0 6px;\">·</span></div>" +
          '<div style="flex:0 0 40px;display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:6px 10px;border-bottom:1px solid rgba(0,229,255,0.35);background:repeating-linear-gradient(90deg,transparent,transparent 11px,rgba(0,229,255,0.06) 12px);">' +
          '<div style="letter-spacing:0.16em;font-size:13px;color:#C8FF00;">CITY BREAKER 2012</div>' +
          '<div id="bo-profile-chip" style="border:1px solid #FF2D95;color:#FF2D95;padding:4px 8px;font-size:11px;letter-spacing:0.1em;">PROFIL: BALANS</div>' +
          '<div id="bo-hud-chip" style="border:1px solid #00E5FF;color:#00E5FF;padding:4px 8px;font-size:11px;letter-spacing:0.08em;margin-left:auto;">WYNIK 0 · ŻYCIA 3</div></div>' +
          '<div id="bo-hook" style="flex:0 0 auto;padding:6px 10px;font-size:12px;letter-spacing:0.06em;color:#C8FF00;border-bottom:1px solid rgba(200,255,0,0.2);">TWOJE MIASTO WŁAŚNIE WYGENEROWAŁO CI LEVEL.</div>' +
          '<div id="bo-mantra" style="flex:0 0 auto;padding:4px 10px;font-size:10px;letter-spacing:0.12em;color:#00E5FF;">BLOKI = FAKTY. PIŁKA = ZMIANA.</div>' +
          '<div id="cb-stage" style="position:relative;flex:1;min-height:120px;background:#0A1020;overflow:hidden;"></div>' +
          '<div id="bo-legend" style="flex:0 0 auto;padding:4px 10px;font-size:10px;letter-spacing:0.06em;color:#3DFF9A;">GĘSTOŚĆ · ZIELEŃ · ZABUDOWA · PODMIOTY</div>' +
          '<div id="bo-profiles" style="pointer-events:auto;flex:0 0 auto;display:flex;flex-wrap:wrap;gap:6px;padding:8px 10px;"></div>' +
          '<div id="bo-state-hint" style="flex:0 0 auto;padding:0 10px 8px;font-size:11px;letter-spacing:0.1em;color:#C8FF00;"></div>' +
          '<div id="bo-result" style="pointer-events:auto;display:none;margin:0 10px 10px;border:1px solid #FF2D95;background:rgba(7,11,20,0.95);padding:8px;font-size:11px;color:#00E5FF;text-align:center;"></div>' +
          '<div id="cb-gen" style="display:none;pointer-events:none;position:absolute;inset:28px 0 0 0;z-index:20;background:rgba(7,11,20,0.88);color:#C8FF00;font-family:Verdana,Arial,sans-serif;letter-spacing:0.14em;align-items:center;justify-content:center;flex-direction:column;gap:10px;text-align:center;padding:24px;"></div>';
        host.insertBefore(root, canvas);
        const stage = document.getElementById("cb-stage");
        const world = document.createElement("div");
        world.id = "cb-world";
        world.style.cssText = "pointer-events:none;position:absolute;inset:0;z-index:3;";
        world.innerHTML =
          '<div id="cb-grid" style="position:absolute;inset:0;background-image:linear-gradient(rgba(0,229,255,0.10) 1px,transparent 1px),linear-gradient(90deg,rgba(0,229,255,0.10) 1px,transparent 1px);background-size:28px 28px;"></div>' +
          '<div id="cb-radar" style="position:absolute;right:10px;top:10px;width:72px;height:72px;border:1px solid rgba(0,229,255,0.5);border-radius:50%;box-shadow:0 0 0 10px rgba(0,229,255,0.08),inset 0 0 18px rgba(200,255,0,0.12);"></div>' +
          '<div id="cb-radar-dot" style="position:absolute;right:42px;top:28px;width:6px;height:6px;background:#C8FF00;border-radius:50%;"></div>' +
          '<div id="cb-callouts" style="position:absolute;left:8px;top:8px;font-size:9px;letter-spacing:0.1em;line-height:1.5;">' +
          '<div style="color:#C8FF00;">→ GĘSTOŚĆ</div><div style="color:#3DFF9A;">→ ZIELEŃ</div>' +
          '<div style="color:#00E5FF;">→ ZABUDOWA</div><div style="color:#FF2D95;">→ PODMIOTY</div></div>' +
          '<div id="cb-arena-tag" style="position:absolute;left:8px;bottom:8px;font-size:9px;letter-spacing:0.12em;color:rgba(0,229,255,0.85);">ARENA · PROFIL PUBLICZNY · NIE STATYSTYKA 2012</div>' +
          '<div id="cb-scan" style="position:absolute;inset:0;background:repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(7,11,20,0.14) 3px);"></div>';
        canvas.style.cssText =
          "position:relative;z-index:2;width:100%;height:100%;object-fit:contain;touch-action:none;display:block;";
        stage.appendChild(canvas);
        stage.appendChild(world);
        canvas.style.cssText = "position:relative;z-index:2;width:100%;height:100%;object-fit:contain;touch-action:none;display:block;";
        const bar = document.getElementById("bo-profiles");
        const specs = [
          ["balanced-mid", "BALANS"],
          ["dense-spike", "GESTE"],
          ["green-open", "ZIELONY"],
          ["mixed-spike", "SPIKE"],
          ["low-edge", "MIN"],
          ["high-edge", "MAX"],
        ];
        for (let i = 0; i < specs.length; i++) {
          const a = document.createElement("a");
          a.href = "?profile=" + specs[i][0];
          a.textContent = specs[i][1];
          a.style.cssText =
            "pointer-events:auto;border:1px solid #C8FF00;background:#C8FF00;color:#1A1410;padding:8px 10px;font-size:11px;letter-spacing:0.08em;text-decoration:none;min-height:44px;display:inline-flex;align-items:center;box-sizing:border-box;";
          bar.appendChild(a);
        }
        const shareBtn = document.createElement("button");
        shareBtn.id = "bo-share";
        shareBtn.type = "button";
        shareBtn.textContent = "UDOSTĘPNIJ";
        shareBtn.style.cssText =
          "pointer-events:auto;display:none;border:1px solid #FF2D95;background:#070B14;color:#FF2D95;padding:8px 10px;font-size:11px;min-height:44px;";
        shareBtn.onclick = function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          const text =
            window.__boShareText ||
            "CITY BREAKER 2012 · level z danych publicznych · to interpretacja gry, nie werdykt o miescie.";
          function fallback() {
            if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text);
            shareBtn.textContent = "SKOPIOWANO";
          }
          if (navigator.share) navigator.share({ text: text }).catch(fallback);
          else fallback();
        };
        bar.appendChild(shareBtn);
        startCityGenSequence(profileLabel(pid));
      } catch (eShell) {
        return;
      }
    }
    if (typeof window !== "undefined") {
      window.__boForceResult = function (kind) {
        try {
          runtimeScene.getScene().getVariables().get("GameState").setString(kind);
        } catch (eF) {}
      };
      window.__boShareText =
        "Rozbilam/em level CITY BREAKER 2012 · profil " +
        profileLabel(pid) +
        " · wynik " +
        Math.floor(scoreVal) +
        " · to interpretacja gry, nie dane z 2012.";
    }
    if (runtimeScene._boPrevLives == null) runtimeScene._boPrevLives = lives;
    if (lives < runtimeScene._boPrevLives) {
      runtimeScene._boLifeDropUntil = Date.now() + 900;
      const win = document.getElementById("cb-window");
      if (win) {
        win.style.boxShadow = "0 0 0 1px #070B14, 8px 8px 0 #FF2D95, 0 0 24px #FF2D95";
        setTimeout(function () {
          win.style.boxShadow = "0 0 0 1px #070B14, 8px 8px 0 #FF2D95";
        }, 280);
      }
    }
    runtimeScene._boPrevLives = lives;
    const genEl = document.getElementById("cb-gen");
    if (genEl && (gameState === "Lost" || gameState === "Won" || gameState === "GamePlay")) {
      genEl.style.display = "none";
    }
    const hud = document.getElementById("bo-hud-chip");
    if (hud) hud.textContent = "WYNIK " + Math.floor(scoreVal) + " · ŻYCIA " + Math.floor(livesVal);
    const shareEl = document.getElementById("bo-share");
    if (shareEl) shareEl.style.display = gameState === "Lost" || gameState === "Won" ? "inline-flex" : "none";
    const chip = document.getElementById("bo-profile-chip");
    if (chip) chip.textContent = "PROFIL: " + profileLabel(pid);
    const arena = document.getElementById("cb-arena-tag");
    if (arena) arena.textContent = "ARENA · " + profileLabel(pid) + " · NIE STATYSTYKA 2012";
    const narrow = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(max-width: 380px)").matches;
    const call = document.getElementById("cb-callouts");
    const radar = document.getElementById("cb-radar");
    const rdot = document.getElementById("cb-radar-dot");
    if (call) call.style.display = narrow ? "none" : "block";
    if (radar) radar.style.opacity = narrow ? "0.35" : "1";
    if (rdot) rdot.style.display = narrow ? "none" : "block";
    const mantra = document.getElementById("bo-mantra");
    if (mantra && window.matchMedia) {
      mantra.style.display = window.matchMedia("(max-width: 430px)").matches && gameState !== "NotStarted" ? "none" : "block";
    }
    const legend = document.getElementById("bo-legend");
    if (legend) legend.style.display = gameState === "NotStarted" ? "block" : "none";
    const hook = document.getElementById("bo-hook");
    if (hook) hook.style.display = gameState === "NotStarted" ? "block" : "none";
    const pick = document.getElementById("bo-profiles");
    if (pick) pick.style.display = gameState === "NotStarted" || gameState === "Lost" || gameState === "Won" ? "flex" : "none";
    const hint = document.getElementById("bo-state-hint");
    if (hint) {
      if (runtimeScene._boLifeDropUntil && Date.now() < runtimeScene._boLifeDropUntil && gameState === "NotStarted") {
        hint.textContent = "ŻYCIE UTRACONE · SYGNAŁ CIENIEJE · RUSZ PALETKĄ";
      } else if (gameState === "NotStarted") hint.textContent = "ODPAL LEVEL · RUSZ PALETKA · DOTKNIJ / SPACJA";
      else if (gameState === "Lost") hint.textContent = "SYGNAŁ UTRACONY · JESZCZE RAZ (R)";
      else if (gameState === "Won") hint.textContent = "LEVEL ROZBITY";
      else hint.textContent = "";
    }
    const res = document.getElementById("bo-result");
    if (res) {
      if (gameState === "Lost" || gameState === "Won") {
        res.style.display = "block";
        res.innerHTML =
          "PROFIL " +
          profileLabel(pid) +
          " · WYNIK " +
          Math.floor(scoreVal) +
          "<br>GĘSTOŚĆ · ZIELEŃ · ZABUDOWA · PODMIOTY" +
          "<br>PIŁKA ZROBIŁA Z FAKTÓW KURZ. TO INTERPRETACJA GRY, NIE WERDYKT O MIEŚCIE." +
          "<br>Rok 2012 = estetyka, nie data statystyk.";
      } else res.style.display = "none";
    }
  }

  // Public-domain museum records provide visible context for one isolated test fixture.
  // Original City Breaker layouts remain unchanged for all other fixture/profile ids.
  function updateMuseumPanel(items) {
    if (typeof document === "undefined" || typeof window === "undefined") return;
    if (window.__boBoardId !== "met-vase-open-data") return;
    const root = document.getElementById("cb-window");
    if (!root || !Array.isArray(items) || !items.length) return;
    const title = document.getElementById("cb-titlebar");
    if (title) title.firstElementChild.textContent = "MUSEUM BREAKER — THE MET / CC0 OPEN ACCESS";
    const heading = root.querySelector('[style*="letter-spacing:0.16em"]');
    if (heading) heading.textContent = "MUSEUM BREAKER";
    const chip = document.getElementById("bo-profile-chip");
    if (chip) chip.textContent = "THE MET · " + items.length + " EKSPONATÓW";
    const arena = document.getElementById("cb-arena-tag");
    if (arena) arena.textContent = "ARCHIWUM THE MET · KOLUMNY WG DATY KATALOGOWEJ";
    const legend = document.getElementById("bo-legend");
    if (legend) legend.textContent = "WIEK STARSZEGO OBIEKTU = WYŻSZA KOLUMNA · INTERPRETACJA ARCADE";
    const hook = document.getElementById("bo-hook");
    if (hook) hook.textContent = "11 AUTENTYCZNYCH OBIEKTÓW → JEDNA PLANSZA.";
    const bar = document.getElementById("bo-profiles");
    if (bar) bar.style.display = "none";
    let panel = document.getElementById("bo-museum-panel");
    if (!panel) {
      panel = document.createElement("div");
      panel.id = "bo-museum-panel";
      panel.style.cssText = "flex:0 0 auto;display:flex;align-items:center;gap:8px;min-height:92px;padding:6px 10px;background:#141b2c;border-top:1px solid #00e5ff;color:#e9e6de;";
      const img = document.createElement("img");
      img.id = "bo-met-image";
      img.alt = "Wybrany obiekt muzealny The Met";
      img.style.cssText = "width:82px;height:78px;object-fit:contain;background:#050915;flex-shrink:0;";
      img.loading = "lazy";
      panel.appendChild(img);
      const description = document.createElement("div");
      description.style.cssText = "flex:1;min-width:0;display:flex;flex-direction:column;gap:4px;";
      const a = document.createElement("a");
      a.id = "bo-met-link";
      a.target = "_blank";
      a.rel = "noopener noreferrer";
      a.style.cssText = "color:#c8ff00;font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;";
      description.appendChild(a);
      const year = document.createElement("span");
      year.id = "bo-met-year";
      year.style.cssText = "font-size:11px;color:#00e5ff;";
      description.appendChild(year);
      const source = document.createElement("span");
      source.textContent = "Źródło: The Metropolitan Museum of Art · Open Access";
      source.style.cssText = "font-size:9px;color:#b8c3d1;";
      description.appendChild(source);
      panel.appendChild(description);
      const buttons = document.createElement("div");
      buttons.style.cssText = "display:flex;flex-direction:column;gap:4px;flex-shrink:0;";
      for (const [label, delta] of [["◀", -1], ["▶", 1]]) {
        const btn = document.createElement("button");
        btn.textContent = label;
        btn.type = "button";
        btn.setAttribute("aria-label", delta > 0 ? "Następny eksponat" : "Poprzedni eksponat");
        btn.style.cssText = "background:#c8ff00;color:#111;padding:7px 12px;min-width:40px;border:0;min-height:35px;cursor:pointer;";
        btn.onclick = function () {
          window.__boMetIndex = ((window.__boMetIndex || 0) + delta + items.length) % items.length;
          renderMuseumObject(items);
        };
        buttons.appendChild(btn);
      }
      panel.appendChild(buttons);
      if (bar && bar.parentElement) bar.parentElement.insertBefore(panel, bar);
      else root.appendChild(panel);
      window.__boMetIndex = 0;
      window.__boMetRecords = items;
    }
    const res = document.getElementById("bo-result");
    if (res && res.style.display === "block") {
      res.textContent = "PLANSZA THE MET · " + (window.__boBoard?.brickCount || 0) +
        " BLOKÓW · DANE KATALOGOWE JAKO PARAMETRY GRY (NIE OCENA SZTUKI)";
    }
    window.__boMuseumReady = true;
    renderMuseumObject(items);
  }

  function renderMuseumObject(items) {
    const i = window.__boMetIndex || 0;
    if (window.__boMetLastIndex === i) return;
    window.__boMetLastIndex = i;
    const item = items[i];
    const img = document.getElementById("bo-met-image");
    const link = document.getElementById("bo-met-link");
    const year = document.getElementById("bo-met-year");
    if (img) img.src = item.image;
    if (link) {
      link.textContent = (i + 1) + "/" + items.length + " " + item.title;
      link.href = item.url;
    }
    if (year) year.textContent = "DATA WG KATALOGU: " + item.year +
      " · ID " + item.id;
  }

  function applyLabBoard(scene, boards, cityBoards) {
    let id = "balanced-mid";
    let err = "";
    let board = null;
    try {
      const search = typeof window !== "undefined" && window.location ? window.location.search || "" : "";
      const params = new URLSearchParams(search);
      const profile = params.get("profile");
      const q = params.get("fixture");
      if (profile) {
        if (cityBoards && cityBoards[profile]) {
          board = cityBoards[profile];
          id = profile;
        } else {
          err = "unknown_profile";
          board = (cityBoards && cityBoards["balanced-mid"]) || null;
          id = "balanced-mid";
        }
      } else if (q) {
        if (boards && boards[q]) id = q;
        else err = "unknown_fixture";
      } else if (cityBoards && cityBoards["balanced-mid"]) {
        board = cityBoards["balanced-mid"];
        id = "balanced-mid";
      }
    } catch (eQ) {
      err = "query_parse";
    }
    if (!board) board = (boards && (boards[id] || boards["balanced-mid"])) || null;
    if (typeof window !== "undefined") {
      window.__boBoardError = err;
      window.__boBoard = board;
      window.__boBoardSignature = board ? board.signature : "";
      window.__boBoardId = board ? board.id : "";
      window.__boFactorDebug = board && board.debug ? board.debug : null;
    }
    if (!board) return;

    const names = ["Block_1", "Block_2", "Block_3"];
    for (let n = 0; n < names.length; n++) {
      const list = scene.getObjects(names[n]).slice();
      for (let i = 0; i < list.length; i++) {
        if (typeof list[i].deleteFromScene === "function") list[i].deleteFromScene(scene);
      }
    }

    const objNames = ["", "Block_1", "Block_2", "Block_3"];
    const cellW = 160;
    const cellH = 40;
    const gw = board.columns * cellW;
    const ox = (scene.getGame().getGameResolutionWidth() - gw) / 2;
    const oy = 168;
    for (let r = 0; r < board.rows; r++) {
      for (let c = 0; c < board.columns; c++) {
        const cell = board.cells[r][c];
        if (!cell) continue;
        const fam = cell.family || "gestosc";
        const famIdx = { gestosc: 0, zielen: 1, zabudowa: 2, podmioty: 3 }[fam] || 0;
        const obj = scene.createObject(objNames[cell.hp]);
        if (!obj) continue;
        obj.setPosition(ox + c * cellW, oy + r * cellH);
        try {
          if (typeof obj.setSize === "function") obj.setSize(cellW - 8, cellH - 6);
          else {
            if (typeof obj.setWidth === "function") obj.setWidth(cellW - 8);
            if (typeof obj.setHeight === "function") obj.setHeight(cellH - 6);
          }
        } catch (eSz) {}
        try {
          obj.getVariables().get("Health").setNumber(cell.hp);
        } catch (eH) {}
        try {
          if (typeof obj.setAnimation === "function") obj.setAnimation(famIdx);
          else {
            const anim = typeof obj.getBehavior === "function" ? obj.getBehavior("Animation") : null;
            if (anim && typeof anim.setAnimationIndex === "function") anim.setAnimationIndex(famIdx);
          }
        } catch (eA) {}
      }
    }

    const pads = scene.getObjects("Paddle");
    if (pads.length && !scene._boPaddleScaled) {
      scene._boPaddleScaled = true;
      const p = pads[0];
      p.setWidth(p.getWidth() * (board.paddleWidthScale || 1));
    }
  }
})(runtimeScene);

};
gdjs.GameCode.eventsList30 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("Ball"), gdjs.GameCode.GDBallObjects1);
gdjs.copyArray(runtimeScene.getObjects("Barrier"), gdjs.GameCode.GDBarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("Paddle"), gdjs.GameCode.GDPaddleObjects1);
{gdjs.evtTools.camera.hideLayer(runtimeScene, "EndCard");
}
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber((( gdjs.GameCode.GDBallObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDBallObjects1[0].getScaleX()));
}
{runtimeScene.getScene().getVariables().getFromIndex(3).setNumber((( gdjs.GameCode.GDPaddleObjects1.length === 0 ) ? 0 :gdjs.GameCode.GDPaddleObjects1[0].getScaleX()));
}
{for(var i = 0, len = gdjs.GameCode.GDBarrierObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDBarrierObjects1[i].hide();
}
}

{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList8(runtimeScene);
}


{


gdjs.GameCode.eventsList10(runtimeScene);
}


{


gdjs.GameCode.eventsList16(runtimeScene);
}


{


gdjs.GameCode.eventsList19(runtimeScene);
}


{


gdjs.GameCode.eventsList21(runtimeScene);
}


{


gdjs.GameCode.eventsList27(runtimeScene);
}


{


gdjs.GameCode.eventsList29(runtimeScene);
}


{


gdjs.GameCode.userFunc0xaf8488(runtimeScene);

}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDBallObjects1.length = 0;
gdjs.GameCode.GDBallObjects2.length = 0;
gdjs.GameCode.GDBallObjects3.length = 0;
gdjs.GameCode.GDBallObjects4.length = 0;
gdjs.GameCode.GDBallObjects5.length = 0;
gdjs.GameCode.GDPaddleObjects1.length = 0;
gdjs.GameCode.GDPaddleObjects2.length = 0;
gdjs.GameCode.GDPaddleObjects3.length = 0;
gdjs.GameCode.GDPaddleObjects4.length = 0;
gdjs.GameCode.GDPaddleObjects5.length = 0;
gdjs.GameCode.GDBlock_95951Objects1.length = 0;
gdjs.GameCode.GDBlock_95951Objects2.length = 0;
gdjs.GameCode.GDBlock_95951Objects3.length = 0;
gdjs.GameCode.GDBlock_95951Objects4.length = 0;
gdjs.GameCode.GDBlock_95951Objects5.length = 0;
gdjs.GameCode.GDBlock_95952Objects1.length = 0;
gdjs.GameCode.GDBlock_95952Objects2.length = 0;
gdjs.GameCode.GDBlock_95952Objects3.length = 0;
gdjs.GameCode.GDBlock_95952Objects4.length = 0;
gdjs.GameCode.GDBlock_95952Objects5.length = 0;
gdjs.GameCode.GDBlock_95953Objects1.length = 0;
gdjs.GameCode.GDBlock_95953Objects2.length = 0;
gdjs.GameCode.GDBlock_95953Objects3.length = 0;
gdjs.GameCode.GDBlock_95953Objects4.length = 0;
gdjs.GameCode.GDBlock_95953Objects5.length = 0;
gdjs.GameCode.GDPowerUpObjects1.length = 0;
gdjs.GameCode.GDPowerUpObjects2.length = 0;
gdjs.GameCode.GDPowerUpObjects3.length = 0;
gdjs.GameCode.GDPowerUpObjects4.length = 0;
gdjs.GameCode.GDPowerUpObjects5.length = 0;
gdjs.GameCode.GDBarrierObjects1.length = 0;
gdjs.GameCode.GDBarrierObjects2.length = 0;
gdjs.GameCode.GDBarrierObjects3.length = 0;
gdjs.GameCode.GDBarrierObjects4.length = 0;
gdjs.GameCode.GDBarrierObjects5.length = 0;
gdjs.GameCode.GDScoreLabelObjects1.length = 0;
gdjs.GameCode.GDScoreLabelObjects2.length = 0;
gdjs.GameCode.GDScoreLabelObjects3.length = 0;
gdjs.GameCode.GDScoreLabelObjects4.length = 0;
gdjs.GameCode.GDScoreLabelObjects5.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects1.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects2.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects3.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects4.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects5.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects1.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects3.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects4.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects5.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects3.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects4.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects5.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects1.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects2.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects3.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects4.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects5.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects1.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects2.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects3.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects4.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects5.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects1.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects2.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects3.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects4.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects5.length = 0;
gdjs.GameCode.GDOnFireParticleObjects1.length = 0;
gdjs.GameCode.GDOnFireParticleObjects2.length = 0;
gdjs.GameCode.GDOnFireParticleObjects3.length = 0;
gdjs.GameCode.GDOnFireParticleObjects4.length = 0;
gdjs.GameCode.GDOnFireParticleObjects5.length = 0;
gdjs.GameCode.GDPaddleLineObjects1.length = 0;
gdjs.GameCode.GDPaddleLineObjects2.length = 0;
gdjs.GameCode.GDPaddleLineObjects3.length = 0;
gdjs.GameCode.GDPaddleLineObjects4.length = 0;
gdjs.GameCode.GDPaddleLineObjects5.length = 0;
gdjs.GameCode.GDBackdropObjects1.length = 0;
gdjs.GameCode.GDBackdropObjects2.length = 0;
gdjs.GameCode.GDBackdropObjects3.length = 0;
gdjs.GameCode.GDBackdropObjects4.length = 0;
gdjs.GameCode.GDBackdropObjects5.length = 0;
gdjs.GameCode.GDCitySkylineObjects1.length = 0;
gdjs.GameCode.GDCitySkylineObjects2.length = 0;
gdjs.GameCode.GDCitySkylineObjects3.length = 0;
gdjs.GameCode.GDCitySkylineObjects4.length = 0;
gdjs.GameCode.GDCitySkylineObjects5.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects1.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects2.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects3.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects4.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects5.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects1.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects2.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects3.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects4.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects5.length = 0;

gdjs.GameCode.eventsList30(runtimeScene);
gdjs.GameCode.GDBallObjects1.length = 0;
gdjs.GameCode.GDBallObjects2.length = 0;
gdjs.GameCode.GDBallObjects3.length = 0;
gdjs.GameCode.GDBallObjects4.length = 0;
gdjs.GameCode.GDBallObjects5.length = 0;
gdjs.GameCode.GDPaddleObjects1.length = 0;
gdjs.GameCode.GDPaddleObjects2.length = 0;
gdjs.GameCode.GDPaddleObjects3.length = 0;
gdjs.GameCode.GDPaddleObjects4.length = 0;
gdjs.GameCode.GDPaddleObjects5.length = 0;
gdjs.GameCode.GDBlock_95951Objects1.length = 0;
gdjs.GameCode.GDBlock_95951Objects2.length = 0;
gdjs.GameCode.GDBlock_95951Objects3.length = 0;
gdjs.GameCode.GDBlock_95951Objects4.length = 0;
gdjs.GameCode.GDBlock_95951Objects5.length = 0;
gdjs.GameCode.GDBlock_95952Objects1.length = 0;
gdjs.GameCode.GDBlock_95952Objects2.length = 0;
gdjs.GameCode.GDBlock_95952Objects3.length = 0;
gdjs.GameCode.GDBlock_95952Objects4.length = 0;
gdjs.GameCode.GDBlock_95952Objects5.length = 0;
gdjs.GameCode.GDBlock_95953Objects1.length = 0;
gdjs.GameCode.GDBlock_95953Objects2.length = 0;
gdjs.GameCode.GDBlock_95953Objects3.length = 0;
gdjs.GameCode.GDBlock_95953Objects4.length = 0;
gdjs.GameCode.GDBlock_95953Objects5.length = 0;
gdjs.GameCode.GDPowerUpObjects1.length = 0;
gdjs.GameCode.GDPowerUpObjects2.length = 0;
gdjs.GameCode.GDPowerUpObjects3.length = 0;
gdjs.GameCode.GDPowerUpObjects4.length = 0;
gdjs.GameCode.GDPowerUpObjects5.length = 0;
gdjs.GameCode.GDBarrierObjects1.length = 0;
gdjs.GameCode.GDBarrierObjects2.length = 0;
gdjs.GameCode.GDBarrierObjects3.length = 0;
gdjs.GameCode.GDBarrierObjects4.length = 0;
gdjs.GameCode.GDBarrierObjects5.length = 0;
gdjs.GameCode.GDScoreLabelObjects1.length = 0;
gdjs.GameCode.GDScoreLabelObjects2.length = 0;
gdjs.GameCode.GDScoreLabelObjects3.length = 0;
gdjs.GameCode.GDScoreLabelObjects4.length = 0;
gdjs.GameCode.GDScoreLabelObjects5.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects1.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects2.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects3.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects4.length = 0;
gdjs.GameCode.GDStartCard_9595titleObjects5.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects1.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects2.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects3.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects4.length = 0;
gdjs.GameCode.GDStartCard_9595Sub_9595titleObjects5.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects1.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects2.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects3.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects4.length = 0;
gdjs.GameCode.GDEnd_9595Card_9595TitleObjects5.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects1.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects2.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects3.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects4.length = 0;
gdjs.GameCode.GDHome_9595ButtonObjects5.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects1.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects2.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects3.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects4.length = 0;
gdjs.GameCode.GDReplay_9595ButtonObjects5.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects1.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects2.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects3.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects4.length = 0;
gdjs.GameCode.GDLife_9595CounterObjects5.length = 0;
gdjs.GameCode.GDOnFireParticleObjects1.length = 0;
gdjs.GameCode.GDOnFireParticleObjects2.length = 0;
gdjs.GameCode.GDOnFireParticleObjects3.length = 0;
gdjs.GameCode.GDOnFireParticleObjects4.length = 0;
gdjs.GameCode.GDOnFireParticleObjects5.length = 0;
gdjs.GameCode.GDPaddleLineObjects1.length = 0;
gdjs.GameCode.GDPaddleLineObjects2.length = 0;
gdjs.GameCode.GDPaddleLineObjects3.length = 0;
gdjs.GameCode.GDPaddleLineObjects4.length = 0;
gdjs.GameCode.GDPaddleLineObjects5.length = 0;
gdjs.GameCode.GDBackdropObjects1.length = 0;
gdjs.GameCode.GDBackdropObjects2.length = 0;
gdjs.GameCode.GDBackdropObjects3.length = 0;
gdjs.GameCode.GDBackdropObjects4.length = 0;
gdjs.GameCode.GDBackdropObjects5.length = 0;
gdjs.GameCode.GDCitySkylineObjects1.length = 0;
gdjs.GameCode.GDCitySkylineObjects2.length = 0;
gdjs.GameCode.GDCitySkylineObjects3.length = 0;
gdjs.GameCode.GDCitySkylineObjects4.length = 0;
gdjs.GameCode.GDCitySkylineObjects5.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects1.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects2.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects3.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects4.length = 0;
gdjs.GameCode.GDGDevelop_9595WaterMarkObjects5.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects1.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects2.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects3.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects4.length = 0;
gdjs.GameCode.GDGUIBackGroundObjects5.length = 0;


return;

}

gdjs['GameCode'] = gdjs.GameCode;
