MUSEUM BREAKER — technical web preview
Use a local HTTP server after extracting this ZIP:
  python3 -m http.server 8080
Then open http://localhost:8080/

The preview defaults to The Met museum fixture. You can browse source records with image, date, and link.
THIS IS NOT A COMMERCIAL RELEASE. It reuses City Breaker mechanics and credits GDevelop Breakout template (MIT), Kenney/open-source sample content and The Met public-domain catalog metadata/images (see source docs). Media in the museum panel loads over HTTPS from The Met; no guarantee of offline image availability.
