MUSEUM BREAKER — HTML5 technical preview
After extraction, from this folder run: python3 -m http.server 8080
Open: http://localhost:8080/
Default: museum fixture with 11 real Met objects and 30 bricks. Museum photo/source controls at the bottom.
Mobile note: responsive shell works in 390x844 emulator, but the landscape 1920x1080 game arena is heavily letterboxed on a portrait phone. Rotate to landscape or play on desktop for this preview.
Not a commercial release. The Met CC0 Open Access catalog objects are filtered; baseline third-party audio/fonts/UI require release review. Museum thumbnails require HTTPS access to The Met CDN.
